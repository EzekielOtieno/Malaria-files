```python
import matplotlib.pyplot as plt
import numpy as np

# Ground truth (manual counting)
manual = [12.14, 17.00, 16.33]

# Measured parasitemia values
ofm = [7.87, 18.00, 19.28]
lab = [0.72, 1.33, 1.73]

# Accuracy calculations
def calc_accuracy(measured, ground_truth):
    return [100 - abs((m - g) / g) * 100 for m, g in zip(measured, ground_truth)]

ofm_accuracy = calc_accuracy(ofm, manual)
lab_accuracy = calc_accuracy(lab, manual)

# Plotting
labels = [f'Sample {i+1}' for i in range(len(manual))]
x = np.arange(len(labels))
width = 0.35

fig, ax = plt.subplots()
bars1 = ax.bar(x - width/2, ofm, width, label='OFM', color='blue')
bars2 = ax.bar(x + width/2, lab, width, label='Lab Technician', color='orange')

# Add accuracy labels on top of bars
for bar, acc in zip(bars1, ofm_accuracy):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.05, f'{acc:.1f}%', ha='center', fontsize=9)

for bar, acc in zip(bars2, lab_accuracy):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.05, f'{acc:.1f}%', ha='center', fontsize=9)

# Labels and legend
ax.set_ylabel('Parasitemia (%)')
ax.set_title('Parasitemia with Accuracy for OFM and Lab Technician')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()

plt.tight_layout()
plt.show()

```


    
![png](output_0_0.png)
    



```python
import matplotlib.pyplot as plt
import numpy as np

# Data
labels = ['Slide A']
ofm_parasitemia = [7.87]
lab_parasitemia = [0.72]
ofm_accuracy = [64.83]
lab_accuracy = [5.93]

x = np.arange(len(labels))
width = 0.1

# Plotting
fig, ax = plt.subplots()
bars1 = ax.bar(x - width/2, ofm_parasitemia, width, label='OFM', color='blue')
bars2 = ax.bar(x + width/2, lab_parasitemia, width, label='Lab Technician', color='orange')

# Accuracy labels
for bar, acc in zip(bars1, ofm_accuracy):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.2, f'{acc:.2f}%', ha='center', fontsize=9)

for bar, acc in zip(bars2, lab_accuracy):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.2, f'{acc:.2f}%', ha='center', fontsize=9)

# Labels and title
ax.set_ylabel('Parasitemia (%)')
ax.set_title('Slide A: Parasitemia and Accuracy')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()

plt.ylim(0, max(ofm_parasitemia + lab_parasitemia) + 2)
plt.tight_layout()
plt.show()

```


    
![png](output_1_0.png)
    



```python
import matplotlib.pyplot as plt
import numpy as np

# Data for Slide A
labels = ['Slide A']
ofm_parasitemia = [7.87]
lab_parasitemia = [0.72]
ground_truth = [12.14]

# Accuracy calculation
def calculate_accuracy(measured, ground):
    return [100 - abs((m - g) / g) * 100 for m, g in zip(measured, ground)]

ofm_accuracy = calculate_accuracy(ofm_parasitemia, ground_truth)
lab_accuracy = calculate_accuracy(lab_parasitemia, ground_truth)

# X-axis positions
x = np.arange(len(labels))
width = 0.35

# Plot
fig, ax = plt.subplots()
bars1 = ax.bar(x - width/2, ofm_parasitemia, width, label='OFM', color='blue')
bars2 = ax.bar(x + width/2, lab_parasitemia, width, label='Lab Technician', color='orange')

# Add accuracy labels above bars
for bar, acc in zip(bars1, ofm_accuracy):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3, f'{acc:.2f}%', ha='center', fontsize=10, color='blue')

for bar, acc in zip(bars2, lab_accuracy):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3, f'{acc:.2f}%', ha='center', fontsize=10, color='orange')

# Styling
ax.set_ylabel('Parasitemia (%)')
ax.set_title('Parasitemia and Accuracy Comparison - Slide A')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()
plt.ylim(0, max(max(ofm_parasitemia), max(lab_parasitemia)) + 2)

plt.tight_layout()
plt.show()

```


    
![png](output_2_0.png)
    



```python
import matplotlib.pyplot as plt
import numpy as np

# Ground truth (manual counting)
manual = [12.14, 17.00, 16.33]

# Measured parasitemia values
ofm = [7.87, 18.00, 19.28]
lab = [0.72, 1.33, 1.73]

# Accuracy calculations
def calc_accuracy(measured, ground_truth):
    return [100 - abs((m - g) / g) * 100 for m, g in zip(measured, ground_truth)]

ofm_accuracy = calc_accuracy(ofm, manual)
lab_accuracy = calc_accuracy(lab, manual)

# Labels for slides
labels = ['Slide A', 'Slide B', 'Slide C']
x = np.arange(len(labels))
width = 0.35

fig, ax = plt.subplots()
bars1 = ax.bar(x - width/2, ofm, width, label='OFM', color='blue')
bars2 = ax.bar(x + width/2, lab, width, label=' Human analysis', color='orange')

# Add accuracy labels on top of bars
for bar, acc in zip(bars1, ofm_accuracy):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.05, f'{acc:.1f}%', ha='center', fontsize=9)

for bar, acc in zip(bars2, lab_accuracy):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.05, f'{acc:.1f}%', ha='center', fontsize=9)

# Labels and legend
ax.set_ylabel('Parasitemia (%)')
ax.set_title('Parasitemia with Accuracy for OFM and Human microscopist analysis')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()

plt.tight_layout()
plt.show()

```


    
![png](output_3_0.png)
    



```python
import matplotlib.pyplot as plt
import numpy as np

# Ground truth (manual counting)
manual = [12.14, 17.00, 16.33]

# Measured parasitemia values
ofm = [7.87, 18.00, 19.28]
lab = [0.72, 1.33, 1.73]

# Accuracy calculations
def calc_accuracy(measured, ground_truth):
    return [100 - abs((m - g) / g) * 100 for m, g in zip(measured, ground_truth)]

ofm_accuracy = calc_accuracy(ofm, manual)
lab_accuracy = calc_accuracy(lab, manual)

# Labels for slides
labels = ['Slide A', 'Slide B', 'Slide C']
x = np.arange(len(labels))
width = 0.35

# High-resolution plot
fig, ax = plt.subplots(dpi=300)
bars1 = ax.bar(x - width/2, ofm, width, label='OFM', color='blue')
bars2 = ax.bar(x + width/2, lab, width, label='Human Analysis', color='orange')

# Add accuracy labels on top of bars
for bar, acc in zip(bars1, ofm_accuracy):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.2, f'{acc:.1f}%', ha='center', fontsize=7)

for bar, acc in zip(bars2, lab_accuracy):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.2, f'{acc:.1f}%', ha='center', fontsize=7)

# Labels and legend
ax.set_ylabel('Parasitemia (%)', fontsize=9)
ax.set_title("Comparison of Parasitemia Accuracy: OFM vs Human macroscopist analysis", fontsize=10, weight='bold')
ax.set_xticks(x)
ax.set_xticklabels(labels, fontsize=8)
ax.legend(fontsize=8)

plt.ylim(0, max(ofm + lab) + 5)
plt.tight_layout()

# Save as PNG with 300 DPI
plt.savefig("parasitemia_comparison.png", dpi=300)

plt.show()

```


    
![png](output_4_0.png)
    



```python
import matplotlib.pyplot as plt
import numpy as np

# Data
slides = ['Slide A', 'Slide B', 'Slide C']
ofm_vals = [7.87, 18.00, 19.28]
lab_vals = [0.72, 1.33, 1.73]
manual_vals = [12.14, 17.00, 16.33]

# Calculate accuracy
def calc_accuracy(measured, ground_truth):
    return [100 - abs((m - g) / g) * 100 for m, g in zip(measured, ground_truth)]

ofm_acc = calc_accuracy(ofm_vals, manual_vals)
lab_acc = calc_accuracy(lab_vals, manual_vals)

# Plot each slide
for i in range(len(slides)):
    labels = ['OFM Parasitemia', 'OFM Accuracy', 'Lab Parasitemia', 'Lab Accuracy']
    values = [ofm_vals[i], ofm_acc[i], lab_vals[i], lab_acc[i]]
    colors = ['blue', 'lightblue', 'orange', 'wheat']

    x = np.arange(len(labels))
    fig, ax = plt.subplots(dpi=300)
    bars = ax.bar(x, values, color=colors)

    # Add value labels
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, height + 0.5, f'{height:.2f}%', ha='center', fontsize=8)

    # Titles and labels
    ax.set_ylabel('Value (%)', fontsize=9)
    ax.set_title(f'{slides[i]}: Parasitemia and Accuracy Comparison', fontsize=10, weight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=15, fontsize=8)

    plt.ylim(0, max(values) + 10)
    plt.tight_layout()

    # Save each figure
    plt.savefig(f"{slides[i].replace(' ', '_').lower()}_comparison.png", dpi=300)
    plt.show()

```


    
![png](output_5_0.png)
    



    
![png](output_5_1.png)
    



    
![png](output_5_2.png)
    



```python
import matplotlib.pyplot as plt
import numpy as np

# Data
slides = ['Slide A', 'Slide B', 'Slide C']
ofm_vals = [7.87, 18.00, 19.28]
human_vals = [0.72, 1.33, 1.73]  # Previously "lab"
manual_vals = [12.14, 17.00, 16.33]

# Accuracy calculation
def calc_accuracy(measured, ground_truth):
    return [100 - abs((m - g) / g) * 100 for m, g in zip(measured, ground_truth)]

ofm_acc = calc_accuracy(ofm_vals, manual_vals)
human_acc = calc_accuracy(human_vals, manual_vals)

# Plot each slide
for i in range(len(slides)):
    labels = [
        'OFM Parasitemia',
        'OFM Accuracy',
        'Human Parasitemia',
        'Human Accuracy'
    ]
    values = [ofm_vals[i], ofm_acc[i], human_vals[i], human_acc[i]]
    colors = ['blue', 'red', 'orange', 'green']

    x = np.arange(len(labels))
    fig, ax = plt.subplots(dpi=300)
    bars = ax.bar(x, values, color=colors)

    # Add value labels on bars
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, height + 0.5, f'{height:.2f}%', ha='center', fontsize=8)

    # Set labels and title
    ax.set_ylabel('Value (%)', fontsize=9)
    ax.set_title(f'{slides[i]}: Parasitemia and Accuracy Comparison (OFM vs Human Analysis)', fontsize=10, weight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=15, fontsize=8)

    plt.ylim(0, max(values) + 10)
    plt.tight_layout()

    # Save each figure
    filename = f"{slides[i].replace(' ', '_').lower()}_ofm_vs_human.png"
    plt.savefig(filename, dpi=300)
    plt.show()

```


    
![png](output_6_0.png)
    



    
![png](output_6_1.png)
    



    
![png](output_6_2.png)
    



```python
import matplotlib.pyplot as plt
import numpy as np

# Slide A values
ofm = 7.87
human = 0.72
manual = 12.14

# Accuracy
ofm_acc = 100 - abs((ofm - manual) / manual) * 100
human_acc = 100 - abs((human - manual) / manual) * 100

labels = ['OFM Parasitemia', 'OFM Accuracy', 'Human Parasitemia', 'Human Accuracy']
values = [ofm, ofm_acc, human, human_acc]
colors = ['blue', 'red', 'orange', 'green']

x = np.arange(len(labels))
fig, ax = plt.subplots(dpi=300)
bars = ax.bar(x, values, color=colors)

for bar in bars:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.5, f'{height:.2f}%', ha='center', fontsize=8)

ax.set_ylabel('Value (%)')
ax.set_title('Slide A: OFM vs Human Microscopic Analysis')
ax.set_xticks(x)
ax.set_xticklabels(labels, rotation=15, fontsize=8)

plt.ylim(0, max(values) + 10)
plt.tight_layout()

plt.savefig(r"C:\Users\Ezekiel\Desktop\test 3\test 3\slide_a_ofm_vs_human.png", dpi=300)
plt.show()

```


    
![png](output_7_0.png)
    



```python
import matplotlib.pyplot as plt
import numpy as np

# Slide B values
ofm = 18.00
human = 1.33
manual = 17.00

# Accuracy
ofm_acc = 100 - abs((ofm - manual) / manual) * 100
human_acc = 100 - abs((human - manual) / manual) * 100

labels = ['OFM Parasitemia', 'OFM Accuracy', 'Human Parasitemia', 'Human Accuracy']
values = [ofm, ofm_acc, human, human_acc]
colors = ['blue', 'red', 'orange', 'green']

x = np.arange(len(labels))
fig, ax = plt.subplots(dpi=300)
bars = ax.bar(x, values, color=colors)

for bar in bars:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.5, f'{height:.2f}%', ha='center', fontsize=8)

ax.set_ylabel('Value (%)')
ax.set_title('Slide B: OFM vs Human Microscopic Analysis')
ax.set_xticks(x)
ax.set_xticklabels(labels, rotation=15, fontsize=8)

plt.ylim(0, max(values) + 10)
plt.tight_layout()

plt.savefig(r"C:\Users\Ezekiel\Desktop\test 3\test 3\slide_b_ofm_vs_human.png", dpi=300)
plt.show()

```


    
![png](output_8_0.png)
    



```python
import matplotlib.pyplot as plt
import numpy as np

# Slide C values
ofm = 19.28
human = 1.73
manual = 16.33

# Accuracy
ofm_acc = 100 - abs((ofm - manual) / manual) * 100
human_acc = 100 - abs((human - manual) / manual) * 100

labels = ['OFM Parasitemia', 'OFM Accuracy', 'Human Parasitemia', 'Human Accuracy']
values = [ofm, ofm_acc, human, human_acc]
colors = ['blue', 'red', 'orange', 'green']

x = np.arange(len(labels))
fig, ax = plt.subplots(dpi=300)
bars = ax.bar(x, values, color=colors)

for bar in bars:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 0.5, f'{height:.2f}%', ha='center', fontsize=8)

ax.set_ylabel('Value (%)')
ax.set_title('Slide C: OFM vs Human Microscopic Analysis')
ax.set_xticks(x)
ax.set_xticklabels(labels, rotation=15, fontsize=8)

plt.ylim(0, max(values) + 10)
plt.tight_layout()

plt.savefig(r"C:\Users\Ezekiel\Desktop\test 3\test 3\slide_c_ofm_vs_human.png", dpi=300)
plt.show()

```


    
![png](output_9_0.png)
    



```python

```
